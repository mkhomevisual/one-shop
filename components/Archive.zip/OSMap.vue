<!-- components/OSMap.vue -->
<template>
  <section
    id="pobocky"
    ref="sectionRef"
    class="relative py-24 sm:py-32 bg-white dark:bg-gray-900 transition-colors overflow-visible"
  >
    <!-- LOGISTIC LINES – full width background, centrované na střed skutečné mapy -->
    <div
      class="pointer-events-none absolute left-1/2 -translate-x-1/2 z-0"
      :style="{ top: lineTopPx + 'px', height: '420px' }"
    >
      <LogisticsLines class="text-brand-orange/80" />
    </div>

    <div class="relative z-10 mx-auto max-w-7xl px-6 lg:px-8">
      <!-- Hlavička -->
      <div class="mx-auto max-w-2xl text-center">
        <h2 class="text-sm font-semibold tracking-wide text-brand-orange">{{ t.kicker }}</h2>
        <p class="mt-3 text-4xl sm:text-5xl font-semibold tracking-tight text-brand-anthracite dark:text-white">
          {{ t.title }}
        </p>
        <p class="mt-6 text-lg text-neutral-700 dark:text-neutral-300">
          {{ t.subtitle }}
        </p>
      </div>

      <!-- MAPA -->
      <div ref="mapFrame" class="relative mx-auto mt-16 w-3/4 rounded-2xl overflow-hidden shadow-sm">
        <div ref="mapBox" class="relative w-full aspect-[16/9] isolate" @click="logPercentCoords">
          <!-- POZADÍ MAPY JAKO IMG (object-contain = žádný ořez) -->
          <img
            ref="mapImg"
            :src="bgUrl"
            alt=""
            class="absolute inset-0 h-full w-full object-contain select-none pointer-events-none"
            @load="onImgLoad"
            draggable="false"
          />

          <!-- PINY (počítané vůči skutečné vykreslené oblasti obrázku) -->
          <div class="absolute inset-0 z-10">
            <button
              v-for="pin in pins"
              :key="pin.id"
              class="group absolute"
              :style="pinStyle(pin)"
              @click.stop="open(pin)"
              :aria-label="displayTitle(pin)"
            >
              <span class="relative inline-block -translate-x-1/2 -translate-y-full">
                <!-- glow -->
                <span
                  class="absolute -z-10 left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2
                         h-28 w-28 rounded-full bg-brand-orange/28 blur-lg"></span>
                <!-- pin -->
                <svg class="h-14 w-14 text-brand-orange drop-shadow" viewBox="0 0 24 24" aria-hidden="true">
                  <path fill="currentColor" d="M12 2c-3.866 0-7 3.134-7 7 0 5.25 7 13 7 13s7-7.75 7-13c0-3.866-3.134-7-7-7z"/>
                  <circle cx="12" cy="9" r="2.6" fill="white"/>
                </svg>
              </span>

              <!-- tooltip -->
              <span
                class="pointer-events-none absolute left-1/2 top-3 translate-x-[-50%] translate-y-2
                       rounded-md bg-white/95 dark:bg-neutral-800/95 px-2 py-1 text-xs font-medium
                       text-brand-anthracite dark:text-white shadow ring-1 ring-black/5 dark:ring-white/10
                       opacity-0 group-hover:opacity-100 transition"
              >
                {{ displayTitle(pin) }}
              </span>
            </button>
          </div>

          <!-- DETAIL PINU -->
          <transition name="fade">
            <div
              v-if="active"
              class="absolute left-1/2 bottom-3 z-20 w-[min(100%,30rem)] -translate-x-1/2
                     rounded-xl bg-white/95 dark:bg-neutral-800/95 text-sm text-neutral-800 dark:text-neutral-100
                     shadow-xl ring-1 ring-black/5 dark:ring-white/10 backdrop-blur"
            >
              <div class="p-4">
                <div class="flex items-start gap-3">
                  <div class="mt-1 h-5 w-5 flex items-center justify-center rounded-full bg-brand-orange text-white text-[10px] font-bold">●</div>
                  <div class="min-w-0">
                    <p class="font-semibold text-brand-anthracite dark:text-white">{{ displayTitle(active) }}</p>
                    <p class="mt-1 text-neutral-600 dark:text-neutral-300">{{ active.address }}</p>
                    <p class="mt-1 text-neutral-700 dark:text-neutral-200">
                      <span class="font-medium">{{ t.hoursLabel }}:</span> {{ displayHours(active) }}
                    </p>
                  </div>
                </div>

                <div class="mt-4 flex items-center gap-2">
                  <a
                    class="inline-flex items-center justify-center rounded-md bg-brand-orange px-3.5 py-2
                           text-sm font-semibold text-white shadow hover:opacity-90 focus-visible:outline
                           focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-brand-orange/60"
                    :href="gmapsUrl(active)"
                    target="_blank" rel="noopener"
                  >{{ t.openInMaps }}</a>

                  <button
                    class="ml-auto rounded-md px-3 py-2 text-sm text-neutral-600 dark:text-neutral-300
                           hover:bg-black/5 dark:hover:bg-white/5"
                    @click="active = null"
                  >{{ t.close }}</button>
                </div>
              </div>
            </div>
          </transition>
        </div>
      </div>
    </div>
  </section>
</template>

<script setup lang="ts">
import { ref, computed, onMounted, onBeforeUnmount, nextTick } from 'vue'
import LogisticsLines from '@/components/decor/LogisticsLines.vue'
import lightMap from '@/assets/map/os-cz-light.png'
import darkMap  from '@/assets/map/os-cz-dark.png'

/* ---------- i18n ---------- */
type Lang = 'cz' | 'vn'
const lang = ref<Lang>('cz')
const dict = {
  cz: {
    kicker: 'Naše pobočky',
    title: 'Mapa našich prodejních míst',
    subtitle: 'Mrkněte, kde nás najdete. Další prodejny postupně přidáváme.',
    hoursLabel: 'Otevírací doba',
    openInMaps: 'Otevřít v Google Maps',
    close: 'Zavřít',
  },
  vn: {
    kicker: 'Chi nhánh của chúng tôi',
    title: 'Bản đồ điểm bán hàng',
    subtitle: 'Xem nơi có thể tìm thấy chúng tôi. Sẽ tiếp tục bổ sung các cửa hàng.',
    hoursLabel: 'Giờ mở cửa',
    openInMaps: 'Mở bằng Google Maps',
    close: 'Đóng',
  }
} as const
const t = computed(() => dict[lang.value])

/* ---------- Pins (x/y v % vzhledem k originální mapě) ---------- */
type Pin = {
  id: number
  x: number // %
  y: number // %
  titleCz: string
  titleVn?: string
  address: string
  hoursCz?: string
  hoursVn?: string
}
const pins = ref<Pin[]>([
  { id: 1, x: 43.2, y: 42.0, titleCz: 'ONESHOP Stochov',     address: 'Jaroslava Šípka 188, 273 03 Stochov',        hoursCz: 'Po–So 7:00–19:30, Ne 8:00–19:30', hoursVn: 'Thứ 2–7 7:00–19:30, CN 8:00–19:30' },
  { id: 2, x: 51.4, y: 52.0, titleCz: 'ONESHOP Mnichovice',  address: 'Masarykovo nám. 729, 251 64 Mnichovice',     hoursCz: 'Po–So 8:30–18:00, Ne 12:00–17:00', hoursVn: 'Thứ 2–7 8:30–18:00, CN 12:00–17:00' },
  { id: 3, x: 56.8, y: 64.4, titleCz: 'PH Diskont Tábor',     address: 'Světlogorská 2767/8, 390 05 Tábor 5',        hoursCz: 'Po–Ne 8:00–19:00',                hoursVn: 'Thứ 2–CN 8:00–19:00' },
  { id: 4, x: 46.8, y: 69.8, titleCz: 'OD Labuť Blatná',      address: 'J. P. Koubka 43, 388 01 Blatná',             hoursCz: 'Po–Ne 8:00–19:00',                hoursVn: 'Thứ 2–CN 8:00–19:00' },
])

function displayTitle(p: Pin) { return lang.value === 'vn' ? (p.titleVn || p.titleCz) : p.titleCz }
function displayHours(p: Pin) { return lang.value === 'vn' ? (p.hoursVn || p.hoursCz || '') : (p.hoursCz || '') }

/* ---------- Dark/Light podklad mapy ---------- */
const prefersDark = ref(false)
let mo: MutationObserver | null = null
onMounted(() => {
  const update = () => (prefersDark.value = document.documentElement.classList.contains('dark'))
  update()
  mo = new MutationObserver(update)
  mo.observe(document.documentElement, { attributes: true, attributeFilter: ['class'] })

  // jazyk z localStorage + poslouchat navbar
  const saved = localStorage.getItem('lang')
  if (saved === 'cz' || saved === 'vn') lang.value = saved as Lang
  window.addEventListener('langchange', onLangChange as any)
})
onBeforeUnmount(() => {
  mo?.disconnect()
  window.removeEventListener('langchange', onLangChange as any)
})
function onLangChange(e: any) {
  if (e?.detail?.lang === 'cz' || e?.detail?.lang === 'vn') lang.value = e.detail.lang
}
const bgUrl = computed(() => (prefersDark.value ? darkMap : lightMap))

/* ---------- Výpočet reálné vykreslené oblasti IMG (object-contain) ---------- */
const mapBox = ref<HTMLElement | null>(null)
const mapImg = ref<HTMLImageElement | null>(null)

/** Obdélník skutečné mapy uvnitř boxu (v px) */
const imgRect = ref({ left: 0, top: 0, width: 0, height: 0 })
/** Pomocná funkce – spočti rect podle poměru stran */
function recalcImgRect() {
  const box = mapBox.value
  const img = mapImg.value
  if (!box || !img) return
  const boxRect = box.getBoundingClientRect()
  // získej poměr stran obrázku (přes naturalWidth/Height)
  const iw = img.naturalWidth || 1600
  const ih = img.naturalHeight || 900
  const ir = iw / ih
  const br = boxRect.width / boxRect.height

  let w, h, x, y
  if (br < ir) {
    // box je „užší“ → šířka na 100 %, výška dopočítaná, vertikální letterbox
    w = boxRect.width
    h = w / ir
    x = 0
    y = (boxRect.height - h) / 2
  } else {
    // box je „vyšší“ → výška na 100 %, horizontální letterbox
    h = boxRect.height
    w = h * ir
    x = (boxRect.width - w) / 2
    y = 0
  }
  imgRect.value = { left: x, top: y, width: w, height: h }
  // přepočti linku na střed skutečné mapy
  updateLineTop()
}
function onImgLoad() { recalcImgRect() }

function pinStyle(p: Pin) {
  const r = imgRect.value
  const left = r.left + (p.x / 100) * r.width
  const top  = r.top  + (p.y / 100) * r.height
  return { left: `${left}px`, top: `${top}px` }
}

/* ---------- Detail pinu + Maps odkaz ---------- */
const active = ref<Pin | null>(null)
const open = (p: Pin) => (active.value = p)
const gmapsUrl = (p: Pin) =>
  `https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(p.address || displayTitle(p))}`

/* ---------- Full-width linka zarovnaná na střed skutečné mapy ---------- */
const sectionRef = ref<HTMLElement | null>(null)
const lineTopPx = ref(0)
function updateLineTop() {
  const sec = sectionRef.value
  const box = mapBox.value
  if (!sec || !box) return
  const secRect = sec.getBoundingClientRect()
  const boxRect = box.getBoundingClientRect()
  const r = imgRect.value
  // střed mapy = top boxu + offset obrázku + půlka výšky
  const midY = boxRect.top + r.top + r.height / 2
  lineTopPx.value = midY - secRect.top
}
function onWinChange() { recalcImgRect() }

/* ---------- Mount / Resize / Scroll ---------- */
onMounted(async () => {
  await nextTick()
  recalcImgRect()
  const ro = new ResizeObserver(recalcImgRect)
  mapBox.value && ro.observe(mapBox.value)
  window.addEventListener('resize', onWinChange, { passive: true })
  window.addEventListener('scroll', onWinChange, { passive: true })
})
onBeforeUnmount(() => {
  window.removeEventListener('resize', onWinChange)
  window.removeEventListener('scroll', onWinChange)
})

/* ---------- Logger souřadnic v rámci skutečné mapy ---------- */
function logPercentCoords (e: MouseEvent) {
  const box = mapBox.value
  if (!box) return
  const boxRect = box.getBoundingClientRect()
  const r = imgRect.value
  const cx = e.clientX - boxRect.left
  const cy = e.clientY - boxRect.top
  // když klik mimo mapu (do letterboxu), nereportuj
  if (cx < r.left || cy < r.top || cx > r.left + r.width || cy > r.top + r.height) return
  const x = ((cx - r.left) / r.width) * 100
  const y = ((cy - r.top) / r.height) * 100
  console.log(`%cPin coords → x: ${x.toFixed(2)}%, y: ${y.toFixed(2)}%`, 'color:#F97316;font-weight:bold')
}
</script>

<style scoped>
.fade-enter-active, .fade-leave-active { transition: opacity .18s ease, transform .18s ease }
.fade-enter-from, .fade-leave-to { opacity: 0; transform: translateY(6px) }
</style>
